# GeekStation - Vite + React Starter

Conteúdo gerado pelo assistente. Projeto mínimo pronto para rodar localmente ou subir em Vercel/Netlify.

## Como rodar (local)
1. Instale dependências:
   ```bash
   npm install
   ```
2. Rode em modo dev:
   ```bash
   npm run dev
   ```
3. Abra o endereço mostrado (normalmente http://localhost:5173).

## Observações
- Este projeto usa **TailwindCSS** e **Framer Motion**.
- Imagens e links estão como placeholders (`Imagem` e `#`). Substitua por seus próprios ativos e URLs de afiliado.
- Para produção recomendo conectar um backend/CMS para gerenciar produtos e usar rotas com React Router.

