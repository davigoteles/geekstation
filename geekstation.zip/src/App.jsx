import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

// GeekStation - Single-file React starter (Tailwind + Framer Motion)
// Página "Recomendações" (afiliados placeholders) integrada ao menu

export default function GeekStation() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [view, setView] = useState('home'); // home, news, reviews, shop, membership, recommendations, contact
  const [featured, setFeatured] = useState(null);

  // Produtos de exemplo (placeholders de link)
  const products = [
    // Games
    { id: 1, category: 'Games', title: 'Controle Pro X', price: 'R$ 299,90', img: null, link: '#' },
    { id: 2, category: 'Games', title: 'Headset Gamer Nebula', price: 'R$ 459,90', img: null, link: '#' },
    // Gadgets
    { id: 3, category: 'Gadgets', title: 'Teclado RGB Mecânico', price: 'R$ 399,90', img: null, link: '#' },
    { id: 4, category: 'Gadgets', title: 'Smartwatch Cyber', price: 'R$ 699,90', img: null, link: '#' },
    // HQs
    { id: 5, category: 'HQs', title: 'Edição especial: Saga Sombria', price: 'R$ 89,90', img: null, link: '#' },
    { id: 6, category: 'HQs', title: 'Box Colecionador Vol.1-3', price: 'R$ 249,90', img: null, link: '#' },
  ];

  useEffect(() => {
    // Escolhe aleatoriamente o Produto do Dia a cada carregamento da página de recomendações
    if (view === 'recommendations') {
      const idx = Math.floor(Math.random() * products.length);
      setFeatured(products[idx]);
    }
  }, [view]);

  // Utilitário para listar produtos exceto o featured
  const otherProducts = featured ? products.filter(p => p.id !== featured.id) : products;

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-[#060217] to-[#02010a] text-gray-100 font-sans antialiased overflow-x-hidden">
      {/* Header */}
      <motion.header initial={{ y: -60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.7 }} className="bg-[#080018]/80 border-b border-[#2b0055] backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <div className="text-2xl font-extrabold text-[#00ff9d] drop-shadow-[0_0_10px_#00ff9d] animate-pulse">GeekStation</div>
              <div className="hidden sm:flex gap-3 text-sm text-gray-300">
                {[
                  ['Início','home'],
                  ['Notícias','news'],
                  ['Reviews','reviews'],
                  ['Loja','shop'],
                  ['Clube','membership'],
                  ['Recomendações','recommendations'],
                ].map(([label, key]) => (
                  <button key={key} onClick={() => setView(key)} className="hover:text-[#ff6600] transition-colors">{label}</button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="hidden sm:block text-sm text-gray-400">Monetize: anúncios • afiliados • loja</div>
              <motion.button whileHover={{ scale: 1.05 }} className="px-3 py-1 rounded-md bg-[#ff6600] text-black font-bold shadow-[0_0_8px_#ff6600]" onClick={() => setView('membership')}>Assine</motion.button>
              <button className="sm:hidden p-2 text-[#00ff9d]" onClick={() => setMenuOpen(!menuOpen)} aria-label="menu">☰</button>
            </div>
          </div>
        </div>

        {menuOpen && (
          <nav className="sm:hidden border-t border-[#2b0055] bg-[#080018]">
            <div className="px-4 py-3 space-y-2">
              {['Início','Notícias','Reviews','Loja','Clube','Recomendações'].map((t,i) => (
                <button key={i} onClick={() => { setView(t.toLowerCase()); setMenuOpen(false); }} className="w-full text-left text-gray-300 hover:text-[#ff6600]">{t}</button>
              ))}
            </div>
          </nav>
        )}
      </motion.header>

      {/* Main */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {view === 'home' && (
          <section>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
              <div className="md:col-span-2">
                <h1 className="text-5xl font-extrabold text-[#00ff9d] drop-shadow-[0_0_10px_#00ff9d]">Bem-vindo ao <span className="text-[#ff6600]">GeekStation</span></h1>
                <p className="mt-4 text-lg text-gray-300 max-w-2xl">Notícias, reviews, cultura pop e produtos selecionados para fãs e colecionadores. Monetize com anúncios, programas de afiliados e uma loja própria.</p>

                <div className="mt-6 flex gap-3">
                  <motion.button whileHover={{ scale: 1.03 }} onClick={() => setView('news')} className="px-5 py-2 rounded-md bg-[#ff6600] text-black font-semibold shadow-[0_0_8px_#ff6600]">Ler notícias</motion.button>
                  <motion.button whileHover={{ scale: 1.03 }} onClick={() => setView('shop')} className="px-5 py-2 rounded-md border border-[#00ff9d] text-[#00ff9d]">Visitar loja</motion.button>
                </div>
              </div>

              <aside className="bg-[#0f0030]/70 border border-[#2b0055] rounded-lg p-4">
                <h4 className="font-semibold text-[#00ff9d]">Assine nosso clube</h4>
                <p className="text-sm text-gray-400 mt-2">Conteúdo exclusivo, descontos e sorteios mensais.</p>
                <div className="mt-4">
                  <button onClick={() => setView('membership')} className="w-full px-3 py-2 rounded-md bg-[#00ff9d] text-black font-semibold">Quero assinar</button>
                </div>
              </aside>
            </div>

            <div className="mt-12">
              <h2 className="text-2xl font-bold text-gray-200">Últimos artigos</h2>
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* artigos de exemplo (placeholder) */}
                {[1,2,3].map(i => (
                  <div key={i} className="bg-[#0f0030]/60 border border-[#2b0055] p-4 rounded-lg">
                    <div className="text-xs text-[#ff6600]">Games</div>
                    <h3 className="mt-2 font-semibold text-[#00ff9d]">Título do Artigo {i}</h3>
                    <p className="mt-2 text-sm text-gray-400">Resumo do artigo e link para a página completa.</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {view === 'recommendations' && (
          <section>
            <div className="flex flex-col md:flex-row gap-8">
              {/* Topo: Produto do Dia (meia largura) */}
              <div className="md:w-1/2">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="bg-[#0e0030]/80 border border-[#2b0055] rounded-lg p-6 relative overflow-hidden">
                  <div className="absolute left-4 top-4 bg-[#ff6600] text-black px-2 py-1 rounded-md font-semibold">🔥 Produto do Dia</div>
                  {featured ? (
                    <div className="flex flex-col md:flex-row gap-4 items-center">
                      <div className="h-40 w-full md:w-48 bg-[#1a0038] rounded-md flex items-center justify-center text-gray-500">Imagem</div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-[#00ff9d]">{featured.title}</h3>
                        <div className="mt-2 text-sm text-gray-300">Categoria: <span className="text-[#ff6600]">{featured.category}</span></div>
                        <div className="mt-3 text-xl font-bold text-[#ff6600]">{featured.price}</div>
                        <p className="mt-3 text-sm text-gray-300">Confira as melhores ofertas selecionadas pela nossa equipe. Clique no link para ver mais detalhes.</p>
                        <div className="mt-4 flex gap-3">
                          <motion.a whileHover={{ scale: 1.05, boxShadow: '0 0 12px #00ff9d' }} href={featured.link} target="_blank" rel="noopener noreferrer" className="px-4 py-2 rounded-md bg-[#00ff9d] text-black font-semibold">Comprar com nosso link</motion.a>
                          <button onClick={() => setFeatured(products[Math.floor(Math.random() * products.length)])} className="px-3 py-2 rounded-md border border-[#ff6600] text-[#ff6600]">Trocar</button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-gray-400">Carregando produto...</div>
                  )}
                </motion.div>

                <div className="mt-6">
                  <p className="text-gray-300">Confira nossas recomendações de produtos geek com os melhores preços da galáxia!</p>
                </div>
              </div>

              {/* Grade de produtos */}
              <div className="md:flex-1">
                <h2 className="text-2xl font-bold text-[#00ff9d]">Recomendações</h2>
                <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {otherProducts.map(p => (
                    <motion.div key={p.id} whileHover={{ scale: 1.03, boxShadow: '0 0 12px #00ff9d' }} className="bg-[#0f0030]/70 border border-[#2b0055] p-4 rounded-lg">
                      <div className="h-28 bg-[#1a0038] rounded-md flex items-center justify-center text-gray-500">Imagem</div>
                      <div className="mt-3 flex justify-between items-center">
                        <div>
                          <div className="text-xs text-[#ff6600]">{p.category}</div>
                          <h3 className="font-semibold text-[#00ff9d]">{p.title}</h3>
                          <div className="text-sm text-[#ff6600] font-bold">{p.price}</div>
                        </div>
                        <motion.a whileHover={{ scale: 1.05 }} href={p.link} target="_blank" rel="noopener noreferrer" className="px-3 py-2 rounded-md bg-[#00ff9d] text-black font-semibold">Comprar</motion.a>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-6 text-xs text-gray-400">
                  <em>Alguns links nesta página são afiliados — podemos receber uma comissão por compras realizadas através deles, sem custo adicional para você.</em>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Placeholder para outras views (news, reviews, shop, membership) */}
        {view === 'news' && (
          <section>
            <h2 className="text-3xl font-bold text-[#00ff9d]">Notícias</h2>
            <p className="mt-2 text-gray-300">Seção de notícias — conteudo demo.</p>
          </section>
        )}

        {view === 'reviews' && (
          <section>
            <h2 className="text-3xl font-bold text-[#00ff9d]">Reviews</h2>
            <p className="mt-2 text-gray-300">Seção de reviews — conteudo demo.</p>
          </section>
        )}

        {view === 'shop' && (
          <section>
            <h2 className="text-3xl font-bold text-[#00ff9d]">Loja</h2>
            <p className="mt-2 text-gray-300">Seção de loja — conteudo demo.</p>
          </section>
        )}

        {view === 'membership' && (
          <section>
            <h2 className="text-3xl font-bold text-[#00ff9d]">Clube GeekStation</h2>
            <p className="mt-2 text-gray-300">Assinatura mensal: conteúdo exclusivo, descontos e acesso antecipado a produtos.</p>
            <div className="mt-6 bg-[#0f0030]/80 border border-[#2b0055] p-6 rounded-lg">
              <h3 className="text-lg font-bold text-[#ff6600]">Plano Mensal — R$ 14,90</h3>
              <ul className="mt-4 list-disc pl-5 text-sm text-gray-300">
                <li>Conteúdo premium semanal</li>
                <li>5% de desconto na loja</li>
                <li>Sorteios de colecionáveis</li>
              </ul>
              <motion.button whileHover={{ scale: 1.05 }} className="mt-5 px-5 py-2 bg-[#00ff9d] text-black font-semibold rounded-md">Assinar agora</motion.button>
            </div>
          </section>
        )}

      </main>

      <footer className="border-t border-[#2b0055] bg-[#050014] py-6">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-sm text-gray-500">© {new Date().getFullYear()} GeekStation — Todos os direitos reservados</div>
          <div className="flex gap-4 text-sm text-[#00ff9d]">
            <button onClick={() => setView('contact')} className="hover:text-[#ff6600]">Anuncie</button>
            <a href="#" className="hover:text-[#ff6600]">Política de Privacidade</a>
            <a href="#" className="hover:text-[#ff6600]">Termos</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

/*
  Instruções rápidas:
  - Este arquivo é um componente React pronto para ser colado em um projeto CRA/Vite com TailwindCSS e Framer Motion instalados.
  - Dependências: framer-motion, tailwindcss (configurada).
  - Para usar links reais de afiliado, substitua os campos `link: '#'` pelos URLs do seu programa de afiliados.
  - Para separar em rotas no futuro, integre React Router e transforme cada view em uma rota própria.
*/
